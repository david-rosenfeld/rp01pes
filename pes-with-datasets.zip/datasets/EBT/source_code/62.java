62	"Call Back private Hash table requirementDescTable = new Hash table();

 private Hash table constraintDescTable = new Hash table();

 private Hash table performanceModelTable = new Hash table();

 private PerformanceModel performance model= nullpublic void parseSpeculateInformation(String str)
 {

System. out. println(""Received String = "" + str);

Connection conn = null;

Statement stmt = null;

DriverDescription dd = null;

String eventType = null; // public void identifyPerformanceModels()
 {

Connection conn = null;
ResultSet rs = null;
Statement stmt = null;

String subscriberName = null;

DriverDescription dd = null;

Enumeration subscriberTableEnumeration = nu public void pullInformationFromDoors()
 {

String serverIP = ""140.192.37.150"";

String[] attribute = { ""Value"", ""Logic"", ""Units"", ""Attribute"" };

String subscriberName = null;

Vector constraints = n public void insertValuesInDataBase()
 {

Connection conn = null;

Statement stmt = null;

String subscriberName = null;

DriverDescription dd = null;
Vector driverVector = null;

ConstraintsDescription cd = null;
 public void createExecuteString()
 {

Connection conn = null;

Statement stmt = null;

ResultSet rs = null;

StringBuffer sb = null;

String subscriberName = null;

DriverDescription dd = null;
Vector driverVector public void parseImpactReport(String str)
 {

Connection conn = null;

Statement stmt = null;

Vector constraintsVector = null;
Vector driversVector = null;

ConstraintsDescription constraint = null;

int driverLoop"
