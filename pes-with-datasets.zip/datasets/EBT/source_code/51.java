51	"Driver Inner Panel private JLabel projectNameLabel = null;
 private JLabel modulePathLabel = null;
 private JLabel requirementIdLabel = null;
 private JLabel desLabel = null;
 private JLabel changeLabel = null;
 private JLabel fromLabel = null;String projectName,
String modulePath,
String requirementID,
String description,
String changeAttribute,
String fromValue,
String toValue) {

panel = new JPanel();

panel. setBackground(Color.LIGHTpublic JPanel createPanel() {

return panel;
 }"
