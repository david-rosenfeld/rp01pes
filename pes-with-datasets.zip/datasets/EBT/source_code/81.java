81	"subscribermanager Socket aSocket;
 int ID;
 String EventLog;

 Connection conn;
 ResultSet rs;
 Statement stmt; // constructor, this object will be created in the main method of these class
 SubscriberListener() { } // constructor, this object will be created in the main method of these class
 SubscriberListener(Socket socket, int ID, String ELog)
 {

 this. aSocket = socket;
this.ID = ID;
this.EventLog = ELog;

try
{
public void sendImpactReportToEventServer(String text)
 {

//String impactReport = text;
System. out. println(""WOW IN SEND REPORT"");
System. out. println(""The IR = ""+ text);
String serverIP = ""140. // run method will be execute from the main method when u say Thread. start() in main
 public void run()
 {

System. out. println(""Inside Run method"");

String str="""";
try
{
 // set up for reading the byte data in to characte // start of class from here
 public static void main(String[] args)
 {
// default port number
int port = 1705;
// the message coming from eventserver
String LogName = ""EventLog"";
//LogName is the database name used to log t"
