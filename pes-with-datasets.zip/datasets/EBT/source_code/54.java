54	"eventserver public static void main(String args[])
 {

ThreadPool pool = new ThreadPool(1);

 int port = defaultPort;
 try
 {
 ServerSocket ss = new ServerSocket( port);
 for( int i=0; i<4; i++)
 {
p public final static int defaultPort = 1701;
 ServerSocket theServer;"
