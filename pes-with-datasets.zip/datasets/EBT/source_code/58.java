58	"Subscribed Model private String SubscriberName;
private String SubscriberReqno;
private String SubscriberModule;
private String SubscriberKeyword1;
private String SubscriberKeyword2;public SubscribedModel(String sn, String sr, String sm, String sk1, String sk2)
{
SubscriberName = sn;
SubscriberReqno = sr;
SubscriberModule = sm;
SubscriberKeyword1 = sk1;
SubscriberKeyword2 = s public String GetSubscriberName() { return SubscriberName;} public String GetSubscriberReqno() { return SubscriberReqno;} public String GetSubscriberModule() { return SubscriberModule;} public String GetSubscriberKeyword1() { return SubscriberKeyword1;} public String GetSubscriberKeyword2() { return SubscriberKeyword2;}"
