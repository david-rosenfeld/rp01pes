package beans;

import java.sql.Date;

public class OperatoreAgenzia
(
private String Name, Last Name, Citt�Residenza, Phone, Zip, Address, Email, Password, username;
private Date DoB;

public OperatoreAgenzia () ()
public OperatoreAgenzia (String name, String name, String city, String phone, String ch, String address, String email, String pass, String user, Date date)
(
this.Nome = name;
this.Cognome = surname;
this.Citt�Residenza = city;
this.Telefono = phone;
this.Cap = cap;
this.Indirizzo = address;
this.Email = email;
this.password = pass;
this.Username = user;
this.DataNascita = data;
)

public void setNome (String par1)
(
this.Nome = par1;
)
public String getName ()
(
return Name;
)

public void setCognome (String par1)
(
this.Cognome = par1;
)
public String getCognome ()
(
return Name;
)

public void setCitt�Residenza (String par1)
(
this.Citt�Residenza = par1;
)
public String getCitt�Residenza ()
(
Citt�Residenza return;
)

public void setTelefono (String par1)
(
this.Telefono = par1;
)
public String getTelefono ()
(
return phone;
)

public void setCap (String par1)
(
this.Cap = par1;
)
public String getCap ()
(
return postcode;
)

public void setIndirizzo (String par1)
(
this.Indirizzo = par1;
)
public String getIndirizzo ()
(
return Address;
)

public void setEmail (String par1)
(
this.Email = par1;
)
public String getEmail ()
(
return Email;
)

public void setPassword (String par1)
(
this.password = par1;
)
public String getPassword ()
(
return password;
)

public void setUsername (String par1)
(
this.Username = par1;
)
public String GetUserName ()
(
return username;
)

public void setDataNascita (Date par1)
(
this.DataNascita = par1;
)
public Date getDataNascita ()
(
DoB return;
)
) 