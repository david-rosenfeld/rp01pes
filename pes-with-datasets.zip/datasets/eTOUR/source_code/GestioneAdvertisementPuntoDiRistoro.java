﻿/ **
  * Class that implements management services dell'advertisement
  * For the operator eating place.
  *
  * @ Author Fabio Palladino
  * @ Version 0.1
  *
  * 2007 eTour Project - Copyright by SE @ SA Lab DMI University of Salerno
  * /
package unisa.gps.etour.control.GestioneAdvertisement;

import java.rmi.RemoteException;

public class GestioneAdvertisementPuntoDiRistoro extends GestioneAdvertisement
implements IGestioneAdvertisementPuntoDiRistoro
(

private static final long serialVersionUID = 1L;

/ **
* Constructor, call the constructor of the superclass.
* @ Throws RemoteException
* /
public GestioneAdvertisementPuntoDiRistoro () throws RemoteException
(
super ();
)

)
