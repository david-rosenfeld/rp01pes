﻿/ **
  * Interface that provides management services dell'advertisement
  * Operator eating place.
  *
  * @ Author Fabio Palladino
  * @ Version 0.1
  *
  * 2007 eTour Project - Copyright by SE @ SA Lab DMI University of Salerno
  * /
package unisa.gps.etour.control.GestioneAdvertisement;

public interface extends IGestioneAdvertisementPuntoDiRistoro
IGestioneAdvertisement
(
/ / Empty interface
)