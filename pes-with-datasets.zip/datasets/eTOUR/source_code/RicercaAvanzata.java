	
Class RicercaAvanzata
java.lang.Object
   unisa.gps.etour.control.GestioneRicerche.Ricerca
       unisa.gps.etour.control.GestioneRicerche.RicercaAvanzata
All Implemented Interfaces:
IRicerca

-------------------------------------------------- ------------------------------

public class RicercaAvanzataextends RicercaClasse for managing the Advanced Search

BENE_CULTURALE, PUNTO_DI_RISTORO

RicercaAvanzata (int pIdTurista)
           Class constructor

ottieniNumeroElementiRicerca, ottieniNumeroPagineRicerca, ottieniPaginaRisultatiBeneCulturale, ottieniPaginaRisultatiPuntoDiRistoro, search

GestioneRicerche.Ricerca

RicercaAvanzata
public RicercaAvanzata (int pIdTurista) class constructor

Parameters:
pIdTurista - ID del T